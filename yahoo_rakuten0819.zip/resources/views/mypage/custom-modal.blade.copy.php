<style type="text/css" id="surveyModalStyle">
	.btn-custom {
		background-color: lightgray;
		color: black;
		border: solid 1px darkgray;
		border-radius: 1px;
		margin-right: 2px;
	}

	.btn-custom:hover {
		background-color: gray;
	}

	.input-group {
		padding: 2px;
		margin: 2px;
	}
	.input-group-text {
		background-color: lightgray;
	}
</style>

<div class="modal fade in" id="customModal">
	<div class="modal-dialog modal-xl modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title"><b>【カスタム】モード価格追従設定</b></h4>
				<span><a href="#">使い方を見る</a></span>
				<span class="btn btn-close text-right" data-dismiss="modal" style="font-size: 20px;">&times</span>
			</div>

			<div class="modal-body">
				<ul class="list-group">
				  <li class="list-group-item list-group-item-primary">基本の状態から呼び出す。
				  	<div class="btn-group">
				  		<button class="btn btn-custom">FBA状態合わせ</button>
				  		<button class="btn btn-custom">状態合わせ</button>
				  		<button class="btn btn-custom">FBA最安値</button>
				  		<button class="btn btn-custom">最安値</button>
				  		<button class="btn btn-custom">カート価格</button>
				  	</div>
				  </li>
				  <li class="list-group-item list-group-item-primary">
				  	<span>カスタムプリセットから呼び出す。</span>
				  	<div class="btn-group">
				  		<button class="btn btn-custom">最安+A+P</button>
				  		<button class="btn btn-custom">カート+A+P</button>
				  		<button class="btn btn-custom">自己配送カスタム</button>
				  		<button class="btn btn-custom">カート+A‐P</button>
				  		<button class="btn btn-custom">値上9％</button>
				  		<button class="btn btn-custom">最安+A‐P</button>
				  		<button class="btn btn-custom">値上+10.9％</button>
				  		<button class="btn btn-custom">値上+10.9％</button>
				  		<button class="btn btn-custom">値上+20％</button>
				  	</div>
				  </li>

				  <li class="list-group-item">
				  	<h4><b>追従対象について</b></h4>
				  	<div class="container">
				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【状態】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">全ての状態</button>
					  			<button class="btn btn-custom">自分と同じ状態</button>
					  			<button class="btn btn-custom">自分と同じorより良い状態</button>
					  			<button class="btn btn-custom">可を無視した状態</button>
				  			</div>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【配送設定】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">自分の商品と同じ配送区分</button>
					  			<button class="btn btn-custom">自分と同じ状態</button>
					  			<button class="btn btn-custom">自己発送のみ</button>
					  			<button class="btn btn-custom">FBAのみ</button>
				  			</div>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【ライバル価格】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">最安値</button>
					  			<button class="btn btn-custom">カート価格</button>
				  			</div>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【Amazon無視設定】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">Amazonを追従対象に含める</button>
					  			<button class="btn btn-custom">Amazonを無視する</button>
				  			</div>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【マケプレプライムのライバルについて】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">自己発送として追いかける</button>
					  			<button class="btn btn-custom">FBAとして追いかける</button>
				  			</div>
				  		</div>
				  	</div>

				  	<h4><b>価格変更について</b></h4>
				  	<div class="container">
				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【ポイントの動作設定】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">出品価格のみをライバル合わせる</button>
					  			<button class="btn btn-custom">出品価格とポイントをライバル合わせる</button>
				  			</div>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【値動きの設定】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">値上げ＆値下げする</button>
					  			<button class="btn btn-custom">値上げのみする</button>
					  			<button class="btn btn-custom">値下げのみする</button>
				  			</div>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【赤字ストパーの設定】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">仕入れ価格を赤字ストパーとして使用する</button>
					  			<button class="btn btn-custom">仕入れ価格を赤字ストパーとして使用しない</button>
				  			</div>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【自分だけが出品している時の値上げ】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<div class="col-12">
					  			<button class="btn btn-custom">しない</button>
					  			<button class="btn btn-custom">高値ストパーまで値上げする</button>
				  			</div>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【ライバルが自己発送のときの価格の上乗せ】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<form action="#" id="selfAddon" method="post">
				  				@csrf
					  			<div class="col-12">
					  				<div class="input-group">
					  					<div class="input-group-prepend">
										    <div class="input-group-text">
										      <input type="radio" name="self">
										    </div>
										  </div>
										  <input type="text" name="self-price" value="ライバル価格" disabled />で追従する
					  				</div>
					  				<div class="input-group">
					  					<div class="input-group-prepend">
										    <div class="input-group-text">
										      <input type="radio" name="self">
										    </div>
										  </div>
										  <input type="text" name="self-price" value="" />円upで追従する
					  				</div>
					  				<div class="input-group">
					  					<div class="input-group-prepend">
										    <div class="input-group-text">
										      <input type="radio" name="self">
										    </div>
										  </div>
										  <input type="text" name="self-price" value="" />％upで追従する
					  				</div>
					  			</div>
				  			</form>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【FBAが自己発送のときの価格の上乗せ】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<form action="#" id="fbaAddon" method="post">
				  				@csrf
					  			<div class="col-12">
					  				<div class="input-group">
					  					<div class="input-group-prepend">
										    <div class="input-group-text">
										      <input type="radio" name="fba">
										    </div>
										  </div>
										  <input type="text" name="fba-price" value="ライバル価格" disabled />で追従する
					  				</div>
					  				<div class="input-group">
					  					<div class="input-group-prepend">
										    <div class="input-group-text">
										      <input type="radio" name="fba">
										    </div>
										  </div>
										  <input type="text" name="fba-price" value="" />円upで追従する
					  				</div>
					  				<div class="input-group">
					  					<div class="input-group-prepend">
										    <div class="input-group-text">
										      <input type="radio" name="fba">
										    </div>
										  </div>
										  <input type="text" name="fba-price" value="" />％upで追従する
					  				</div>
					  			</div>
				  			</form>
				  		</div>

				  		<div class="row mb-4">
				  			<div class="col-12">
				  				<p><b>【ブレーキの設定】</b><span><i class="fa fa-question-circle"></i></span></p>
				  			</div>
				  			<form action="#" id="break" method="post">
				  				@csrf
					  			<div class="col-12">
					  				<div class="input-group">
					  					<div class="input-group-prepend">
										    <div class="input-group-text">
										      <input type="radio" name="break">
										    </div>
										  </div>
										  <input type="text" name="break-price" value="ブレーキかけない" disabled />
					  				</div>
					  				<div class="input-group">
					  					<div class="input-group-prepend">
										    <div class="input-group-text">
										      <input type="radio" name="break">
										    </div>
										  </div>
										  <input type="text" name="break-price" value="" />円以上/一日の値動き　でブレーキをかける
					  				</div>
					  			</div>
				  			</form>
				  		</div>
				  	</div>
				  </li>
				</ul>
			</div>

			<div class="modal-footer">
				<button class="btn bg-gradient-primary" data-dismiss="modal">保存</button>
			</div>
		</div>
	</div>
</div>