<link rel="stylesheet" type="text/css" href="{{ asset('assets/fonts/font-awesome.css') }}" />

<link rel="stylesheet" type="text/css" media="all" href="{{asset('assets/plugins/daterangepicker/daterangepicker.css')}}" />
<link href="{{asset('assets/plugins/star-rating/css/star-rating.css')}}" rel="stylesheet" />
<link href="{{asset('assets/plugins/star-rating/themes/krajee-svg/theme.css')}}" rel="stylesheet" />
<link href="{{asset('assets/plugins/toast/css/jquery.toast.css')}}" rel="stylesheet" />

<link href="{{asset('assets/plugins/sweetalert/style.css')}}" rel="stylesheet" />
<link href="{{asset('assets/plugins/sweetalert/sweetalert.css')}}" rel="stylesheet" />

<link href="{{asset('assets/plugins/multi-select/magicsuggest.css')}}" rel="stylesheet" type="text/css">

<link href="{{asset('assets/css/nucleo-icons.css')}}" rel="stylesheet" />
<link href="{{asset('assets/css/nucleo-svg.css')}}" rel="stylesheet" />
<link href="{{ asset('assets/css/webkit.scrollbar.css') }}" rel="stylesheet">

<script src="{{ asset('assets/fonts/kit.fontawesome.js') }}" crossorigin="anonymous"></script>
<link href="{{ asset('assets/fonts/material.icon.css') }}" rel="stylesheet">

<link id="pagestyle" href="{{asset('assets/css/material-kit.css?v=3.0.2')}}" rel="stylesheet" />
